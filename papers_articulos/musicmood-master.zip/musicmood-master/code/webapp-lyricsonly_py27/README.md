### Note

This version does not fetch lyrics from LyricsWikia, instead, lyrics have to be copy & pasted into a text field.


---

After installing the required dependencies in Python 2.7 via

```
pip install -r requirements.txt
```

you can run this web app locally by executing `python main.py`
