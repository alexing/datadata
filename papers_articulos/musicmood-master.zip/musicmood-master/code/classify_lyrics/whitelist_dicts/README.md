
A list of positive and negative opinion words or sentiment words for English (around 6800 words, Hu and Liu, KDD-2004)

Source: [http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html#lexicon](http://www.cs.uic.edu/~liub/FBS/sentiment-analysis.html#lexicon) 


The `pickle` file `semantic_words` is  a Python `set` of both  positive (2006) and negative (4783) words. 