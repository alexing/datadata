`artist_title_25k.sqlite` is a SQLITE3 database of 25,000 random songs from the Million Song Dataset that has been filtered for songs with English lyrics.

Database scheme:

- table: artist_title
- columns: artist (string), title (string) 