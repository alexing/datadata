## Where are the HDF5 files?

Please note that the HDF5 files are not shared in this public GitHub repository to avoid copyright and licensing conflicts. However, if you are interested in obtaining and parsing the HDF5 files, please see the the example code in the IPython notebook  
[ ../../code/collect_data/redownload_lyrics.ipynb](http://nbviewer.ipython.org/github/rasbt/musicmood/blob/master/code/collect_data/redownload_lyrics.ipynb)